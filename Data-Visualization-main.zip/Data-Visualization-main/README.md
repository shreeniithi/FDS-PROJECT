# Data-Visualization
This is a simple program to visualize a data set so that the viewer can easily understand what is present in that data set.
